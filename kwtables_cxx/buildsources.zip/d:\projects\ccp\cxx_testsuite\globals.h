extern int g_localSensorData;
extern int g_suppSensorData;