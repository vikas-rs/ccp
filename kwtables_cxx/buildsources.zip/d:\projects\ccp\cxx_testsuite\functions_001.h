#pragma once
int * returnSensorData(int sensorNum);
int compute_mean(int array[], int size);
void sub_call_freeing_non_heap_memory_002_free(int * memory);
char* memory_leak_001_assign();
