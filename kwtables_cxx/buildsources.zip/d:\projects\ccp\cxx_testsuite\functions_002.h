#pragma once
int* getNullSensor();

int* getLowSensor();

int* getHighSensor(int sensorNum);

void freeing_non_heap_memory_002_free(int * memory);

int *xmalloc();